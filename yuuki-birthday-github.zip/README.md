# Yuuki Birthday Gift 🎂❤️

A small interactive birthday website made for Yuuki.

## Files
- `index.html` — the whole website
- `yuuki.jpg` — the birthday photo

## Publish with GitHub Pages
1. Create a new GitHub repository (for example: `yuuki-birthday`).
2. Upload `index.html` and `yuuki.jpg` to the repository root.
3. Open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Choose the `main` branch and `/ (root)`, then Save.
6. GitHub will give you a public `github.io` link.

Important: keep `yuuki.jpg` in the same folder as `index.html`, because the page loads the photo with `src="yuuki.jpg"`.

The page uses CSS/emoji decorations rather than external character image files, so you don't need to download Spider-Man or Mickey assets.
